class CASES_data:
    Clicked = []
    Filename = None
    All_Countries = dict()
    Time = []
    First_Day = -1
    Last_Day = -1
    IsDrawn = 0


class RECOVERIES_data:
    Clicked = []
    Filename = None
    All_Countries = dict()
    Time = []
    First_Day = -1
    Last_Day = -1
    IsDrawn = 0
